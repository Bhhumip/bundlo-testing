import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import tsconfigPaths from "vite-tsconfig-paths";
import path from "node:path";

export default defineConfig({
    plugins: [react(), tsconfigPaths()],
    resolve: {
        alias: { "~": path.resolve(__dirname, "app") },
    },
    test: {
        environment: "jsdom",
        globals: true,
        setupFiles: ["./tests/setup.js"],
        include: ["tests/**/*.spec.{js,jsx}"],
        exclude: ["node_modules/**", "extensions/**"],
    },
});